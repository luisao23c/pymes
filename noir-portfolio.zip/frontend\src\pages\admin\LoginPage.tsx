import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { FiLock, FiMail } from 'react-icons/fi';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(email, password);
      toast.success('Bienvenido');
      navigate('/admin');
    } catch {
      toast.error('Credenciales incorrectas');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <motion.div
        className="login-card"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="login-header">
          <h1>NOIR</h1>
          <p>Panel de Administración</p>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label><FiMail /> Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@noir.com"
              required
            />
          </div>
          <div className="form-group">
            <label><FiLock /> Contraseña</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
            />
          </div>
          <button type="submit" className="login-btn" disabled={loading}>
            {loading ? 'Ingresando...' : 'Iniciar Sesión'}
          </button>
        </form>
      </motion.div>

      <style>{`
        .login-page { min-height: 100vh; display: flex; align-items: center; justify-content: center; background: var(--bg-primary); }
        .login-card { width: 100%; max-width: 400px; padding: 2.5rem; background: var(--bg-secondary); border: 1px solid var(--border); border-radius: 4px; }
        .login-header { text-align: center; margin-bottom: 2rem; }
        .login-header h1 { font-size: 2rem; font-weight: 200; letter-spacing: 0.3em; color: var(--accent); }
        .login-header p { color: var(--text-secondary); font-size: 0.85rem; font-weight: 300; margin-top: 0.5rem; }
        .form-group { margin-bottom: 1.25rem; }
        .form-group label { display: flex; align-items: center; gap: 0.5rem; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.1em; color: var(--text-secondary); margin-bottom: 0.4rem; }
        .form-group input { width: 100%; background: var(--bg-primary); border: 1px solid var(--border); color: var(--text-primary); padding: 0.8rem 1rem; font-size: 0.9rem; border-radius: 2px; transition: border-color 0.3s; }
        .form-group input:focus { outline: none; border-color: var(--accent); }
        .form-group input::placeholder { color: var(--text-muted); }
        .login-btn { width: 100%; padding: 0.9rem; background: var(--accent); color: var(--bg-primary); font-size: 0.85rem; font-weight: 500; letter-spacing: 0.1em; text-transform: uppercase; border: 1px solid var(--accent); border-radius: 2px; transition: all 0.3s; }
        .login-btn:hover:not(:disabled) { background: transparent; color: var(--accent); }
        .login-btn:disabled { opacity: 0.5; cursor: not-allowed; }
      `}</style>
    </div>
  );
}
