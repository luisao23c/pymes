import { useState } from 'react';
import { motion } from 'framer-motion';
import { api } from '../services/api';
import toast from 'react-hot-toast';
import { FiSend, FiPhone, FiMail, FiMapPin } from 'react-icons/fi';

export default function ContactPage() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', message: '' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) {
      toast.error('Por favor completa los campos obligatorios');
      return;
    }
    setLoading(true);
    try {
      await api.messages.send(form);
      toast.success('Mensaje enviado correctamente');
      setForm({ name: '', email: '', phone: '', message: '' });
    } catch {
      toast.error('Error al enviar el mensaje');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="contact-page">
      <div className="contact-container">
        <motion.div
          className="contact-info"
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1>Contacto</h1>
          <p className="contact-subtitle">¿Tienes un proyecto en mente? Me encantaría escuchar tu historia.</p>
          <div className="contact-details">
            <div className="contact-item">
              <FiPhone />
              <div>
                <span className="contact-label">Teléfono</span>
                <span>+54 9 11 1234-5678</span>
              </div>
            </div>
            <div className="contact-item">
              <FiMail />
              <div>
                <span className="contact-label">Email</span>
                <span>hola@noirphoto.com</span>
              </div>
            </div>
            <div className="contact-item">
              <FiMapPin />
              <div>
                <span className="contact-label">Ubicación</span>
                <span>Buenos Aires, Argentina</span>
              </div>
            </div>
          </div>
          <div className="contact-social">
            <p>Sígueme en redes sociales</p>
            <div className="social-links">
              <a href="#" className="social-link">Instagram</a>
              <a href="#" className="social-link">Behance</a>
            </div>
          </div>
        </motion.div>

        <motion.form
          className="contact-form"
          onSubmit={handleSubmit}
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <div className="form-group">
            <label htmlFor="name">Nombre *</label>
            <input
              id="name"
              type="text"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="Tu nombre"
              required
            />
          </div>
          <div className="form-row">
            <div className="form-group">
              <label htmlFor="email">Email *</label>
              <input
                id="email"
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="tu@email.com"
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="phone">Teléfono</label>
              <input
                id="phone"
                type="tel"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                placeholder="+54 9 11 1234-5678"
              />
            </div>
          </div>
          <div className="form-group">
            <label htmlFor="message">Mensaje *</label>
            <textarea
              id="message"
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              placeholder="Cuéntame sobre tu proyecto o evento..."
              rows={6}
              required
            />
          </div>
          <button type="submit" className="submit-btn" disabled={loading}>
            {loading ? 'Enviando...' : <>Enviar mensaje <FiSend /></>}
          </button>
        </motion.form>
      </div>

      <style>{`
        .contact-page { padding: 8rem 2rem 4rem; max-width: 1200px; margin: 0 auto; }
        .contact-container { display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; align-items: start; }
        .contact-info h1 { font-size: 2.5rem; font-weight: 200; letter-spacing: 0.05em; margin-bottom: 0.5rem; }
        .contact-subtitle { color: var(--text-secondary); font-weight: 300; margin-bottom: 2.5rem; line-height: 1.8; }
        .contact-details { display: flex; flex-direction: column; gap: 1.5rem; margin-bottom: 2.5rem; }
        .contact-item { display: flex; align-items: center; gap: 1rem; }
        .contact-item svg { color: var(--accent); font-size: 1.2rem; flex-shrink: 0; }
        .contact-item div { display: flex; flex-direction: column; }
        .contact-label { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.15em; color: var(--text-muted); margin-bottom: 0.15rem; }
        .contact-item span:last-child { color: var(--text-primary); font-weight: 300; }
        .contact-social p { color: var(--text-muted); font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 0.75rem; }
        .social-links { display: flex; gap: 1rem; }
        .social-link { color: var(--text-secondary); font-size: 0.9rem; transition: color 0.3s; }
        .social-link:hover { color: var(--accent); }
        .contact-form { display: flex; flex-direction: column; gap: 1.25rem; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1.25rem; }
        .form-group { display: flex; flex-direction: column; gap: 0.4rem; }
        .form-group label { font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.1em; color: var(--text-secondary); font-weight: 400; }
        .form-group input, .form-group textarea { background: var(--bg-secondary); border: 1px solid var(--border); color: var(--text-primary); padding: 0.8rem 1rem; font-size: 0.9rem; transition: border-color 0.3s; border-radius: 2px; }
        .form-group input:focus, .form-group textarea:focus { outline: none; border-color: var(--accent); }
        .form-group input::placeholder, .form-group textarea::placeholder { color: var(--text-muted); }
        .form-group textarea { resize: vertical; min-height: 120px; }
        .submit-btn { display: inline-flex; align-items: center; justify-content: center; gap: 0.5rem; padding: 0.9rem 2rem; background: var(--accent); color: var(--bg-primary); font-size: 0.85rem; font-weight: 500; letter-spacing: 0.1em; text-transform: uppercase; transition: all 0.3s; border: 1px solid var(--accent); border-radius: 2px; }
        .submit-btn:hover:not(:disabled) { background: transparent; color: var(--accent); }
        .submit-btn:disabled { opacity: 0.5; cursor: not-allowed; }
        @media (max-width: 768px) {
          .contact-container { grid-template-columns: 1fr; gap: 2rem; }
          .form-row { grid-template-columns: 1fr; }
          .contact-page { padding: 6rem 1rem 2rem; }
        }
      `}</style>
    </div>
  );
}
