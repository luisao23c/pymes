import mongoose, { Schema, Document } from 'mongoose';

export interface IMessage extends Document {
  name: string;
  email: string;
  phone: string;
  message: string;
  eventSlug?: string;
  status: 'unread' | 'read' | 'responded';
  createdAt: Date;
}

const messageSchema = new Schema<IMessage>(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, trim: true, lowercase: true },
    phone: { type: String, default: '' },
    message: { type: String, required: true },
    eventSlug: { type: String, default: '' },
    status: { type: String, enum: ['unread', 'read', 'responded'], default: 'unread' },
  },
  { timestamps: true }
);

messageSchema.index({ status: 1, createdAt: -1 });

export default mongoose.model<IMessage>('Message', messageSchema);
