import dotenv from 'dotenv';
dotenv.config();

import mongoose from 'mongoose';
import User from '../models/User';
import Event from '../models/Event';

const seed = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/noir-portfolio');
    console.log('Connected to MongoDB');

    const existingAdmin = await User.findOne({ email: 'admin@noir.com' });
    if (!existingAdmin) {
      const admin = new User({
        username: 'admin',
        email: 'admin@noir.com',
        password: 'admin123',
        role: 'admin',
      });
      await admin.save();
      console.log('Admin user created: admin@noir.com / admin123');
    } else {
      console.log('Admin user already exists');
    }

    const existingEvents = await Event.countDocuments();
    if (existingEvents === 0) {
      const sampleEvents = [
        {
          title: 'Boda Marina & Carlos',
          slug: 'boda-marina-carlos',
          description: 'Una celebración mágica en la costa, capturando cada momento de amor y alegría.',
          date: new Date('2024-10-15'),
          category: 'bodas',
          coverImage: '',
          coverThumbnail: '',
          featured: true,
          photosCount: 0,
        },
        {
          title: 'Retratos Urbanos',
          slug: 'retratos-urbanos',
          description: 'Sesión de retratos en el corazón de la ciudad, luces y sombras que cuentan historias.',
          date: new Date('2024-09-20'),
          category: 'retratos',
          coverImage: '',
          coverThumbnail: '',
          featured: false,
          photosCount: 0,
        },
        {
          title: 'Atardecer en la Montaña',
          slug: 'atardecer-montana',
          description: 'Paisajes naturales capturados en los momentos más dramáticos del día.',
          date: new Date('2024-08-10'),
          category: 'paisajes',
          coverImage: '',
          coverThumbnail: '',
          featured: false,
          photosCount: 0,
        },
        {
          title: 'Festival de Música',
          slug: 'festival-musica',
          description: 'La energía y el color de un festival nocturno, capturado en Negro y Blanco.',
          date: new Date('2024-07-05'),
          category: 'eventos',
          coverImage: '',
          coverThumbnail: '',
          featured: false,
          photosCount: 0,
        },
      ];
      await Event.insertMany(sampleEvents);
      console.log('Sample events created');
    }

    console.log('Seed completed');
    process.exit(0);
  } catch (error) {
    console.error('Seed error:', error);
    process.exit(1);
  }
};

seed();
