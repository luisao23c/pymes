import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { api } from '../services/api';
import { useInView } from '../hooks/useAnimations';
import { Event } from '../types';

const CATEGORIES = [
  { value: '', label: 'Todos' },
  { value: 'bodas', label: 'Bodas' },
  { value: 'retratos', label: 'Retratos' },
  { value: 'paisajes', label: 'Paisajes' },
  { value: 'eventos', label: 'Eventos' },
  { value: 'editorial', label: 'Editorial' },
];

export default function EventsPage() {
  const [events, setEvents] = useState<Event[]>([]);
  const [category, setCategory] = useState('');
  const [loading, setLoading] = useState(true);
  const { ref, isInView } = useInView(0.1);

  useEffect(() => {
    setLoading(true);
    const params: Record<string, string> = { limit: '50' };
    if (category) params.category = category;
    api.events.list(params)
      .then((data) => setEvents(data.events))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [category]);

  return (
    <div className="events-page">
      <div className="events-header">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          Eventos
        </motion.h1>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          Cada evento cuenta una historia única
        </motion.p>
      </div>

      <div className="category-filter">
        {CATEGORIES.map((cat) => (
          <button
            key={cat.value}
            className={`filter-btn ${category === cat.value ? 'active' : ''}`}
            onClick={() => setCategory(cat.value)}
          >
            {cat.label}
          </button>
        ))}
      </div>

      <div className="events-grid-container" ref={ref}>
        {loading ? (
          <div className="loading-grid">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="skeleton-card" />
            ))}
          </div>
        ) : events.length === 0 ? (
          <div className="empty-state">
            <p>No hay eventos disponibles</p>
          </div>
        ) : (
          <div className="masonry-grid">
            {events.map((event, i) => (
              <motion.div
                key={event._id}
                className="masonry-item"
                initial={{ opacity: 0, y: 40 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: i * 0.08 }}
              >
                <Link to={`/eventos/${event.slug}`} className="event-card-masonry">
                  <div className="event-image-wrapper">
                    {event.coverImage ? (
                      <img src={event.coverThumbnail || event.coverImage} alt={event.title} />
                    ) : (
                      <div className="event-image-placeholder" />
                    )}
                    <div className="event-hover-overlay">
                      <span className="event-category-tag">{event.category}</span>
                      <h3>{event.title}</h3>
                      <p>{event.photosCount} fotos</p>
                    </div>
                    <div className="event-glow" />
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      <style>{`
        .events-page { padding: 8rem 2rem 4rem; max-width: 1400px; margin: 0 auto; }
        .events-header { text-align: center; margin-bottom: 3rem; }
        .events-header h1 { font-size: 2.5rem; font-weight: 200; letter-spacing: 0.1em; margin-bottom: 0.5rem; }
        .events-header p { color: var(--text-secondary); font-weight: 300; letter-spacing: 0.05em; }
        .category-filter { display: flex; justify-content: center; gap: 0.5rem; margin-bottom: 3rem; flex-wrap: wrap; }
        .filter-btn { padding: 0.5rem 1.2rem; background: transparent; border: 1px solid var(--border); color: var(--text-secondary); font-size: 0.8rem; letter-spacing: 0.1em; text-transform: uppercase; transition: all 0.3s; border-radius: 2px; }
        .filter-btn:hover { border-color: var(--accent); color: var(--accent); }
        .filter-btn.active { background: var(--accent); color: var(--bg-primary); border-color: var(--accent); }
        .masonry-grid { columns: 3; column-gap: 1.5rem; }
        .masonry-item { break-inside: avoid; margin-bottom: 1.5rem; }
        .event-card-masonry { display: block; }
        .event-image-wrapper { position: relative; overflow: hidden; border-radius: 4px; cursor: pointer; }
        .event-image-wrapper img { width: 100%; display: block; transition: transform 0.6s ease; }
        .event-card-masonry:hover .event-image-wrapper img { transform: scale(1.03); }
        .event-image-placeholder { width: 100%; aspect-ratio: 3/4; background: linear-gradient(135deg, var(--bg-card) 0%, var(--bg-hover) 100%); }
        .event-hover-overlay { position: absolute; inset: 0; background: linear-gradient(to top, rgba(11,11,11,0.95) 0%, rgba(11,11,11,0.3) 40%, transparent 70%); display: flex; flex-direction: column; justify-content: flex-end; padding: 1.5rem; opacity: 0; transition: opacity 0.4s; }
        .event-card-masonry:hover .event-hover-overlay { opacity: 1; }
        .event-category-tag { font-size: 0.65rem; text-transform: uppercase; letter-spacing: 0.2em; color: var(--accent); margin-bottom: 0.3rem; }
        .event-hover-overlay h3 { font-size: 1.1rem; font-weight: 300; margin-bottom: 0.25rem; }
        .event-hover-overlay p { font-size: 0.8rem; color: var(--text-secondary); }
        .event-glow { position: absolute; inset: -2px; border-radius: 6px; opacity: 0; transition: opacity 0.4s; box-shadow: 0 0 30px rgba(192, 160, 96, 0.3); pointer-events: none; }
        .event-card-masonry:hover .event-glow { opacity: 1; }
        .loading-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.5rem; }
        .skeleton-card { aspect-ratio: 3/4; background: var(--bg-card); border-radius: 4px; animation: pulse 1.5s infinite; }
        @keyframes pulse { 0%, 100% { opacity: 0.5; } 50% { opacity: 0.8; } }
        .empty-state { text-align: center; padding: 4rem 0; color: var(--text-secondary); }
        @media (max-width: 1024px) { .masonry-grid { columns: 2; } }
        @media (max-width: 640px) {
          .masonry-grid { columns: 1; }
          .loading-grid { grid-template-columns: 1fr; }
          .events-page { padding: 6rem 1rem 2rem; }
        }
      `}</style>
    </div>
  );
}
