import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { api } from '../services/api';
import { useTypewriter, useInView } from '../hooks/useAnimations';
import { Event } from '../types';
import { FiArrowRight } from 'react-icons/fi';

function HeroSection() {
  const [featured, setFeatured] = useState<Event | null>(null);
  const { displayText, isComplete } = useTypewriter('Capturando Momentos, Creando Historias', 45);

  useEffect(() => {
    api.events.getFeatured().then(setFeatured).catch(() => {});
  }, []);

  return (
    <section className="hero">
      <div className="hero-bg">
        {featured?.coverImage ? (
          <img src={featured.coverImage} alt={featured.title} />
        ) : (
          <div className="hero-bg-placeholder" />
        )}
        <div className="hero-overlay" />
      </div>
      <div className="hero-content">
        <motion.h1
          className="hero-title"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          <span className="typewriter">{displayText}</span>
          <span className={`cursor ${isComplete ? 'blink' : ''}`}>|</span>
        </motion.h1>
        <motion.p
          className="hero-subtitle"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 1.5 }}
        >
          Fotografía profesional con alma artística
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 2 }}
        >
          <Link to="/eventos" className="hero-cta">
            Ver mi trabajo <FiArrowRight />
          </Link>
        </motion.div>
      </div>
      <style>{`
        .hero { position: relative; height: 100vh; min-height: 600px; display: flex; align-items: center; justify-content: center; overflow: hidden; }
        .hero-bg { position: absolute; inset: 0; }
        .hero-bg img { width: 100%; height: 100%; object-fit: cover; }
        .hero-bg-placeholder { width: 100%; height: 100%; background: linear-gradient(135deg, #0B0B0B 0%, #1a1a2e 50%, #0B0B0B 100%); }
        .hero-overlay { position: absolute; inset: 0; background: linear-gradient(to bottom, rgba(11,11,11,0.3) 0%, rgba(11,11,11,0.7) 60%, rgba(11,11,11,1) 100%); }
        .hero-content { position: relative; z-index: 10; text-align: center; padding: 0 2rem; }
        .hero-title { font-size: clamp(2rem, 5vw, 4rem); font-weight: 200; letter-spacing: 0.05em; line-height: 1.2; margin-bottom: 1.5rem; }
        .typewriter { display: inline; }
        .cursor { color: var(--accent); font-weight: 200; }
        .cursor.blink { animation: blink 0.7s infinite; }
        .hero-subtitle { font-size: 1.1rem; color: var(--text-secondary); font-weight: 300; letter-spacing: 0.15em; text-transform: uppercase; margin-bottom: 2.5rem; }
        .hero-cta { display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.9rem 2.5rem; border: 1px solid var(--accent); color: var(--accent); font-size: 0.85rem; font-weight: 400; letter-spacing: 0.15em; text-transform: uppercase; transition: all 0.3s; }
        .hero-cta:hover { background: var(--accent); color: var(--bg-primary); }
      `}</style>
    </section>
  );
}

function EventsPreview() {
  const [events, setEvents] = useState<Event[]>([]);
  const { ref, isInView } = useInView(0.15);

  useEffect(() => {
    api.events.list({ limit: '4' }).then((data) => setEvents(data.events)).catch(() => {});
  }, []);

  if (events.length === 0) return null;

  return (
    <section className="events-preview" ref={ref}>
      <div className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="section-title">Últimos Trabajos</h2>
          <p className="section-subtitle">Una selección de mis eventos más recientes</p>
        </motion.div>
        <div className="events-grid">
          {events.map((event, i) => (
            <motion.div
              key={event._id}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: i * 0.1 }}
            >
              <Link to={`/eventos/${event.slug}`} className="event-card">
                <div className="event-card-image">
                  {event.coverImage ? (
                    <img src={event.coverThumbnail || event.coverImage} alt={event.title} />
                  ) : (
                    <div className="event-card-placeholder" />
                  )}
                  <div className="event-card-overlay">
                    <span className="event-card-category">{event.category}</span>
                    <h3 className="event-card-title">{event.title}</h3>
                    <span className="event-card-count">{event.photosCount} fotos</span>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
        <motion.div
          className="events-cta"
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.5 }}
        >
          <Link to="/eventos" className="btn-outline">
            Ver todos los eventos <FiArrowRight />
          </Link>
        </motion.div>
      </div>
      <style>{`
        .events-preview { padding: 6rem 2rem; }
        .section-container { max-width: 1400px; margin: 0 auto; }
        .section-title { font-size: 2rem; font-weight: 200; letter-spacing: 0.1em; text-align: center; margin-bottom: 0.5rem; }
        .section-subtitle { text-align: center; color: var(--text-secondary); font-weight: 300; margin-bottom: 3rem; font-size: 0.9rem; letter-spacing: 0.05em; }
        .events-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1.5rem; }
        .event-card { display: block; }
        .event-card-image { position: relative; aspect-ratio: 4/3; overflow: hidden; border-radius: 4px; }
        .event-card-image img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.6s ease; }
        .event-card:hover .event-card-image img { transform: scale(1.05); }
        .event-card-placeholder { width: 100%; height: 100%; background: linear-gradient(135deg, var(--bg-card) 0%, var(--bg-hover) 100%); }
        .event-card-overlay { position: absolute; inset: 0; background: linear-gradient(to top, rgba(11,11,11,0.9) 0%, transparent 60%); display: flex; flex-direction: column; justify-content: flex-end; padding: 1.5rem; opacity: 0; transition: opacity 0.4s; }
        .event-card:hover .event-card-overlay { opacity: 1; }
        .event-card-category { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.15em; color: var(--accent); margin-bottom: 0.3rem; }
        .event-card-title { font-size: 1.1rem; font-weight: 300; margin-bottom: 0.25rem; }
        .event-card-count { font-size: 0.8rem; color: var(--text-secondary); }
        .events-cta { text-align: center; margin-top: 3rem; }
        .btn-outline { display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.8rem 2rem; border: 1px solid var(--border-light); color: var(--text-primary); font-size: 0.85rem; font-weight: 300; letter-spacing: 0.1em; text-transform: uppercase; transition: all 0.3s; }
        .btn-outline:hover { border-color: var(--accent); color: var(--accent); }
        @media (max-width: 768px) {
          .events-grid { grid-template-columns: 1fr; }
          .events-preview { padding: 4rem 1rem; }
        }
      `}</style>
    </section>
  );
}

function ContactCTA() {
  const { ref, isInView } = useInView(0.2);

  return (
    <section className="contact-cta" ref={ref}>
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.6 }}
      >
        <h2 className="section-title">¿Tienes un proyecto en mente?</h2>
        <p className="section-subtitle">Hablemos sobre tu próximo evento</p>
        <Link to="/contacto" className="hero-cta" style={{ marginTop: '1rem' }}>
          Contactar <FiArrowRight />
        </Link>
      </motion.div>
      <style>{`
        .contact-cta { padding: 8rem 2rem; text-align: center; background: var(--bg-secondary); }
      `}</style>
    </section>
  );
}

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <EventsPreview />
      <ContactCTA />
    </>
  );
}
