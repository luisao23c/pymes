import { useState } from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { HiMenu, HiX } from 'react-icons/hi';
import { FiCamera } from 'react-icons/fi';
import { FaWhatsapp } from 'react-icons/fa';

export default function Layout() {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();
  const isHome = location.pathname === '/';

  return (
    <div className="layout">
      <header className={`header ${isHome ? 'header-transparent' : ''}`}>
        <div className="header-inner">
          <Link to="/" className="logo">
            <FiCamera className="logo-icon" />
            <span className="logo-text">NOIR</span>
          </Link>
          <nav className={`nav-desktop ${menuOpen ? 'open' : ''}`}>
            <Link to="/" className="nav-link" onClick={() => setMenuOpen(false)}>Inicio</Link>
            <Link to="/eventos" className="nav-link" onClick={() => setMenuOpen(false)}>Eventos</Link>
            <Link to="/contacto" className="nav-link" onClick={() => setMenuOpen(false)}>Contacto</Link>
          </nav>
          <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <HiX /> : <HiMenu />}
          </button>
        </div>
      </header>

      <AnimatePresence>
        {menuOpen && (
          <motion.div
            className="drawer-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setMenuOpen(false)}
          >
            <motion.nav
              className="drawer"
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'tween', duration: 0.3 }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="drawer-header">
                <span className="logo-text">NOIR</span>
                <button onClick={() => setMenuOpen(false)}><HiX /></button>
              </div>
              <Link to="/" className="drawer-link" onClick={() => setMenuOpen(false)}>Inicio</Link>
              <Link to="/eventos" className="drawer-link" onClick={() => setMenuOpen(false)}>Eventos</Link>
              <Link to="/contacto" className="drawer-link" onClick={() => setMenuOpen(false)}>Contacto</Link>
            </motion.nav>
          </motion.div>
        )}
      </AnimatePresence>

      <main>
        <Outlet />
      </main>

      <a
        href="https://wa.me/5491112345678?text=Hola,%20vi%20tu%20trabajo%20y%20quiero%20un%20presupuesto"
        target="_blank"
        rel="noopener noreferrer"
        className="whatsapp-btn"
        aria-label="Contactar por WhatsApp"
      >
        <FaWhatsapp />
      </a>

      <footer className="footer">
        <div className="footer-inner">
          <p>&copy; 2024 Noir Photography. Todos los derechos reservados.</p>
        </div>
      </footer>

      <style>{`
        .layout { min-height: 100vh; display: flex; flex-direction: column; }
        .header { position: fixed; top: 0; left: 0; right: 0; z-index: 100; padding: 1rem 2rem; transition: all 0.3s ease; background: rgba(11,11,11,0.9); backdrop-filter: blur(10px); }
        .header-transparent { background: transparent; }
        .header-inner { max-width: 1400px; margin: 0 auto; display: flex; align-items: center; justify-content: space-between; }
        .logo { display: flex; align-items: center; gap: 0.5rem; }
        .logo-icon { font-size: 1.5rem; color: var(--accent); }
        .logo-text { font-size: 1.5rem; font-weight: 300; letter-spacing: 0.3em; color: var(--text-primary); }
        .nav-desktop { display: flex; gap: 2rem; }
        .nav-link { font-size: 0.9rem; font-weight: 300; letter-spacing: 0.1em; text-transform: uppercase; color: var(--text-secondary); transition: color 0.3s; position: relative; }
        .nav-link:hover, .nav-link.active { color: var(--accent); }
        .nav-link::after { content: ''; position: absolute; bottom: -4px; left: 0; width: 0; height: 1px; background: var(--accent); transition: width 0.3s; }
        .nav-link:hover::after { width: 100%; }
        .menu-toggle { display: none; background: none; color: var(--text-primary); font-size: 1.5rem; }
        .drawer-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.7); z-index: 200; }
        .drawer { position: fixed; top: 0; right: 0; bottom: 0; width: 280px; background: var(--bg-secondary); padding: 2rem; display: flex; flex-direction: column; gap: 1.5rem; }
        .drawer-header { display: flex; justify-content: space-between; align-items: center; padding-bottom: 1rem; border-bottom: 1px solid var(--border); }
        .drawer-header button { background: none; color: var(--text-primary); font-size: 1.5rem; }
        .drawer-link { font-size: 1.1rem; font-weight: 300; letter-spacing: 0.1em; text-transform: uppercase; color: var(--text-secondary); padding: 0.5rem 0; transition: color 0.3s; }
        .drawer-link:hover { color: var(--accent); }
        main { flex: 1; }
        .whatsapp-btn { position: fixed; bottom: 2rem; right: 2rem; width: 60px; height: 60px; background: #25D366; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.8rem; z-index: 90; box-shadow: 0 4px 20px rgba(37,211,102,0.4); transition: transform 0.3s, box-shadow 0.3s; }
        .whatsapp-btn:hover { transform: scale(1.1); box-shadow: 0 6px 30px rgba(37,211,102,0.6); }
        .footer { padding: 2rem; text-align: center; border-top: 1px solid var(--border); }
        .footer p { color: var(--text-muted); font-size: 0.8rem; font-weight: 300; letter-spacing: 0.05em; }
        @media (max-width: 768px) {
          .nav-desktop { display: none; }
          .menu-toggle { display: block; }
          .header { padding: 1rem; }
        }
      `}</style>
    </div>
  );
}
