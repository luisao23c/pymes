import mongoose, { Schema, Document } from 'mongoose';

export interface IPhoto extends Document {
  eventId: mongoose.Types.ObjectId;
  originalName: string;
  filename: string;
  originalPath: string;
  compressedPath: string;
  thumbnailPath: string;
  width: number;
  height: number;
  size: number;
  order: number;
  caption: string;
  createdAt: Date;
}

const photoSchema = new Schema<IPhoto>(
  {
    eventId: { type: Schema.Types.ObjectId, ref: 'Event', required: true },
    originalName: { type: String, required: true },
    filename: { type: String, required: true },
    originalPath: { type: String, required: true },
    compressedPath: { type: String, required: true },
    thumbnailPath: { type: String, required: true },
    width: { type: Number, default: 0 },
    height: { type: Number, default: 0 },
    size: { type: Number, default: 0 },
    order: { type: Number, default: 0 },
    caption: { type: String, default: '' },
  },
  { timestamps: true }
);

photoSchema.index({ eventId: 1, order: 1 });

export default mongoose.model<IPhoto>('Photo', photoSchema);
