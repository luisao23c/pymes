import mongoose, { Schema, Document } from 'mongoose';

export interface IEvent extends Document {
  title: string;
  slug: string;
  description: string;
  date: Date;
  category: 'bodas' | 'retratos' | 'paisajes' | 'eventos' | 'editorial' | 'otro';
  coverImage: string;
  coverThumbnail: string;
  photosCount: number;
  featured: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const eventSchema = new Schema<IEvent>(
  {
    title: { type: String, required: true, trim: true },
    slug: { type: String, required: true, unique: true, lowercase: true },
    description: { type: String, default: '' },
    date: { type: Date, required: true },
    category: {
      type: String,
      enum: ['bodas', 'retratos', 'paisajes', 'eventos', 'editorial', 'otro'],
      default: 'otro',
    },
    coverImage: { type: String, default: '' },
    coverThumbnail: { type: String, default: '' },
    photosCount: { type: Number, default: 0 },
    featured: { type: Boolean, default: false },
  },
  { timestamps: true }
);

eventSchema.pre('save', function (next) {
  if (!this.slug) {
    this.slug = this.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
  }
  next();
});

export default mongoose.model<IEvent>('Event', eventSchema);
