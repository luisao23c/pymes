import { Request, Response } from 'express';
import Photo from '../models/Photo';
import Event from '../models/Event';
import { processImage, deleteImageFiles } from '../utils/imageProcessor';

export const uploadPhotos = async (req: Request, res: Response) => {
  try {
    const { eventId } = req.body;
    const files = req.files as Express.Multer.File[];

    if (!files || files.length === 0) {
      return res.status(400).json({ error: 'No files uploaded' });
    }

    const event = await Event.findById(eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });

    const photos = [];
    for (const file of files) {
      const result = await processImage(file.filename);
      const photo = new Photo({
        eventId,
        originalName: file.originalname,
        filename: file.filename,
        originalPath: `/uploads/originals/${file.filename}`,
        compressedPath: result.compressed,
        thumbnailPath: result.thumbnail,
        width: result.width,
        height: result.height,
        size: file.size,
        order: files.indexOf(file),
      });
      await photo.save();
      photos.push(photo);
    }

    event.photosCount = await Photo.countDocuments({ eventId });
    await event.save();

    res.status(201).json({ photos, count: photos.length });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const getPhotosByEvent = async (req: Request, res: Response) => {
  try {
    const photos = await Photo.find({ eventId: req.params.eventId }).sort({ order: 1 });
    res.json(photos);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const updatePhoto = async (req: Request, res: Response) => {
  try {
    const { caption, order } = req.body;
    const photo = await Photo.findById(req.params.id);
    if (!photo) return res.status(404).json({ error: 'Photo not found' });

    if (caption !== undefined) photo.caption = caption;
    if (order !== undefined) photo.order = order;
    await photo.save();
    res.json(photo);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const deletePhoto = async (req: Request, res: Response) => {
  try {
    const photo = await Photo.findById(req.params.id);
    if (!photo) return res.status(404).json({ error: 'Photo not found' });

    await deleteImageFiles(photo.originalPath, photo.compressedPath, photo.thumbnailPath);
    await Photo.findByIdAndDelete(req.params.id);

    const event = await Event.findById(photo.eventId);
    if (event) {
      event.photosCount = await Photo.countDocuments({ eventId: photo.eventId });
      await event.save();
    }

    res.json({ message: 'Photo deleted' });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const reorderPhotos = async (req: Request, res: Response) => {
  try {
    const { photoIds } = req.body;
    for (let i = 0; i < photoIds.length; i++) {
      await Photo.findByIdAndUpdate(photoIds[i], { order: i });
    }
    res.json({ message: 'Photos reordered' });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};
