import { Request, Response } from 'express';
import Event from '../models/Event';
import Photo from '../models/Photo';
import { deleteImageFiles } from '../utils/imageProcessor';

export const getEvents = async (req: Request, res: Response) => {
  try {
    const { category, featured, page = '1', limit = '20' } = req.query;
    const filter: any = {};
    if (category) filter.category = category;
    if (featured !== undefined) filter.featured = featured === 'true';

    const skip = (parseInt(page as string) - 1) * parseInt(limit as string);
    const events = await Event.find(filter)
      .sort({ date: -1 })
      .skip(skip)
      .limit(parseInt(limit as string));
    const total = await Event.countDocuments(filter);

    res.json({ events, total, page: parseInt(page as string), pages: Math.ceil(total / parseInt(limit as string)) });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const getEventBySlug = async (req: Request, res: Response) => {
  try {
    const event = await Event.findOne({ slug: req.params.slug });
    if (!event) return res.status(404).json({ error: 'Event not found' });
    res.json(event);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const getEventPhotos = async (req: Request, res: Response) => {
  try {
    const event = await Event.findOne({ slug: req.params.slug });
    if (!event) return res.status(404).json({ error: 'Event not found' });
    const photos = await Photo.find({ eventId: event._id }).sort({ order: 1 });
    res.json(photos);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const createEvent = async (req: Request, res: Response) => {
  try {
    const { title, description, date, category, featured } = req.body;
    let slug = title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');

    const existing = await Event.findOne({ slug });
    if (existing) slug = `${slug}-${Date.now()}`;

    const eventData: any = { title, slug, description, date, category, featured };
    if (req.file) {
      const { processImage } = await import('../utils/imageProcessor');
      const result = await processImage(req.file.filename);
      eventData.coverImage = `/uploads/originals/${req.file.filename}`;
      eventData.coverThumbnail = result.thumbnail;
    }

    const event = new Event(eventData);
    await event.save();
    res.status(201).json(event);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const updateEvent = async (req: Request, res: Response) => {
  try {
    const { title, description, date, category, featured } = req.body;
    const event = await Event.findById(req.params.id);
    if (!event) return res.status(404).json({ error: 'Event not found' });

    if (title) event.title = title;
    if (description !== undefined) event.description = description;
    if (date) event.date = new Date(date);
    if (category) event.category = category;
    if (featured !== undefined) event.featured = featured;

    if (req.file) {
      const { processImage, deleteImageFiles: del } = await import('../utils/imageProcessor');
      if (event.coverImage) {
        await del(event.coverImage, '', event.coverThumbnail);
      }
      const result = await processImage(req.file.filename);
      event.coverImage = `/uploads/originals/${req.file.filename}`;
      event.coverThumbnail = result.thumbnail;
    }

    await event.save();
    res.json(event);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const deleteEvent = async (req: Request, res: Response) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) return res.status(404).json({ error: 'Event not found' });

    const photos = await Photo.find({ eventId: event._id });
    const { deleteImageFiles: del } = await import('../utils/imageProcessor');
    for (const photo of photos) {
      await del(photo.originalPath, photo.compressedPath, photo.thumbnailPath);
    }
    await Photo.deleteMany({ eventId: event._id });

    if (event.coverImage) {
      await del(event.coverImage, '', event.coverThumbnail);
    }
    await Event.findByIdAndDelete(req.params.id);
    res.json({ message: 'Event deleted' });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

export const getFeaturedEvent = async (_req: Request, res: Response) => {
  try {
    const event = await Event.findOne({ featured: true }).sort({ date: -1 });
    res.json(event || null);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};
