import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { FiHome, FiImage, FiMessageSquare, FiLogOut, FiMenu, FiX } from 'react-icons/fi';
import { useState } from 'react';

export default function AdminLayout() {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/admin/login');
  };

  const links = [
    { to: '/admin', icon: <FiHome />, label: 'Dashboard' },
    { to: '/admin/eventos', icon: <FiImage />, label: 'Eventos' },
    { to: '/admin/mensajes', icon: <FiMessageSquare />, label: 'Mensajes' },
  ];

  return (
    <div className="admin-layout">
      <button className="admin-menu-toggle" onClick={() => setSidebarOpen(!sidebarOpen)}>
        {sidebarOpen ? <FiX /> : <FiMenu />}
      </button>
      <aside className={`admin-sidebar ${sidebarOpen ? 'open' : ''}`}>
        <div className="admin-logo">
          <span className="logo-text">NOIR</span>
          <span className="admin-badge">Admin</span>
        </div>
        <nav className="admin-nav">
          {links.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className={`admin-nav-link ${location.pathname === link.to ? 'active' : ''}`}
              onClick={() => setSidebarOpen(false)}
            >
              {link.icon}
              <span>{link.label}</span>
            </Link>
          ))}
        </nav>
        <div className="admin-footer">
          <span className="admin-user">{user?.username}</span>
          <button onClick={handleLogout} className="admin-logout">
            <FiLogOut /> Salir
          </button>
        </div>
      </aside>
      <main className="admin-main">
        <Outlet />
      </main>
      <style>{`
        .admin-layout { display: flex; min-height: 100vh; }
        .admin-sidebar { width: 250px; background: var(--bg-secondary); border-right: 1px solid var(--border); display: flex; flex-direction: column; position: fixed; top: 0; bottom: 0; z-index: 100; }
        .admin-logo { padding: 1.5rem; display: flex; align-items: center; gap: 0.5rem; border-bottom: 1px solid var(--border); }
        .admin-badge { font-size: 0.65rem; background: var(--accent); color: var(--bg-primary); padding: 0.15rem 0.5rem; border-radius: 4px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.1em; }
        .admin-nav { flex: 1; padding: 1rem 0; display: flex; flex-direction: column; }
        .admin-nav-link { display: flex; align-items: center; gap: 0.75rem; padding: 0.75rem 1.5rem; color: var(--text-secondary); transition: all 0.2s; font-size: 0.9rem; }
        .admin-nav-link:hover { color: var(--text-primary); background: var(--bg-hover); }
        .admin-nav-link.active { color: var(--accent); background: var(--accent-dim); border-right: 2px solid var(--accent); }
        .admin-footer { padding: 1rem 1.5rem; border-top: 1px solid var(--border); display: flex; flex-direction: column; gap: 0.5rem; }
        .admin-user { font-size: 0.85rem; color: var(--text-secondary); }
        .admin-logout { display: flex; align-items: center; gap: 0.5rem; background: none; color: var(--danger); font-size: 0.85rem; padding: 0.5rem 0; }
        .admin-logout:hover { color: #e74c3c; }
        .admin-main { flex: 1; margin-left: 250px; padding: 2rem; }
        .admin-menu-toggle { display: none; position: fixed; top: 1rem; left: 1rem; z-index: 200; background: var(--bg-card); color: var(--text-primary); padding: 0.5rem; border-radius: 4px; }
        @media (max-width: 768px) {
          .admin-sidebar { transform: translateX(-100%); transition: transform 0.3s; }
          .admin-sidebar.open { transform: translateX(0); }
          .admin-main { margin-left: 0; padding: 1rem; padding-top: 4rem; }
          .admin-menu-toggle { display: block; }
        }
      `}</style>
    </div>
  );
}
