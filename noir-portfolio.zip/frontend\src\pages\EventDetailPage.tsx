import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { api } from '../services/api';
import { Event, Photo } from '../types';
import { FiArrowLeft, FiX, FiChevronLeft, FiChevronRight } from 'react-icons/fi';
import { FaWhatsapp } from 'react-icons/fa';

export default function EventDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const [event, setEvent] = useState<Event | null>(null);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!slug) return;
    setLoading(true);
    Promise.all([
      api.events.getBySlug(slug),
      api.events.getPhotos(slug),
    ])
      .then(([eventData, photosData]) => {
        setEvent(eventData);
        setPhotos(photosData);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [slug]);

  const openLightbox = (index: number) => setLightboxIndex(index);
  const closeLightbox = () => setLightboxIndex(null);
  const prevPhoto = () => setLightboxIndex((i) => (i !== null && i > 0 ? i - 1 : photos.length - 1));
  const nextPhoto = () => setLightboxIndex((i) => (i !== null && i < photos.length - 1 ? i + 1 : 0));

  useEffect(() => {
    if (lightboxIndex === null) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowLeft') prevPhoto();
      if (e.key === 'ArrowRight') nextPhoto();
    };
    window.addEventListener('keydown', handleKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleKey);
      document.body.style.overflow = '';
    };
  }, [lightboxIndex]);

  const whatsappUrl = `https://wa.me/5491112345678?text=${encodeURIComponent(`Hola, vi tu trabajo en ${event?.title || ''} y quiero un presupuesto`)}`;

  if (loading) {
    return <div className="loading-screen"><div className="spinner" /></div>;
  }

  if (!event) {
    return (
      <div className="not-found">
        <h2>Evento no encontrado</h2>
        <Link to="/eventos">Volver a eventos</Link>
      </div>
    );
  }

  return (
    <div className="event-detail">
      <div className="event-detail-header">
        <Link to="/eventos" className="back-link">
          <FiArrowLeft /> Volver
        </Link>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <span className="event-category">{event.category}</span>
          <h1>{event.title}</h1>
          <p className="event-date">
            {new Date(event.date).toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
          {event.description && <p className="event-description">{event.description}</p>}
        </motion.div>
      </div>

      <div className="photo-grid">
        {photos.map((photo, i) => (
          <motion.div
            key={photo._id}
            className="photo-item"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: i * 0.05 }}
            onClick={() => openLightbox(i)}
          >
            <img src={photo.thumbnailPath || photo.compressedPath} alt={photo.caption || photo.originalName} loading="lazy" />
            <div className="photo-hover">
              <span className="photo-expand">Ver</span>
            </div>
          </motion.div>
        ))}
      </div>

      {photos.length === 0 && (
        <div className="no-photos">
          <p>Próximamente fotos de este evento</p>
        </div>
      )}

      <AnimatePresence>
        {lightboxIndex !== null && (
          <motion.div
            className="lightbox"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <div className="lightbox-header">
              <span>{lightboxIndex + 1} / {photos.length}</span>
              <button onClick={closeLightbox}><FiX /></button>
            </div>
            <button className="lightbox-prev" onClick={prevPhoto}><FiChevronLeft /></button>
            <div className="lightbox-image-container">
              <motion.img
                key={lightboxIndex}
                src={photos[lightboxIndex].compressedPath || photos[lightboxIndex].originalPath}
                alt={photos[lightboxIndex].caption || ''}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.3 }}
              />
            </div>
            <button className="lightbox-next" onClick={nextPhoto}><FiChevronRight /></button>
          </motion.div>
        )}
      </AnimatePresence>

      <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="whatsapp-event-btn">
        <FaWhatsapp /> Pedir presupuesto
      </a>

      <style>{`
        .event-detail { padding: 8rem 2rem 4rem; max-width: 1400px; margin: 0 auto; }
        .event-detail-header { margin-bottom: 3rem; }
        .back-link { display: inline-flex; align-items: center; gap: 0.5rem; color: var(--text-secondary); font-size: 0.85rem; margin-bottom: 1.5rem; transition: color 0.3s; }
        .back-link:hover { color: var(--accent); }
        .event-category { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.2em; color: var(--accent); }
        .event-detail-header h1 { font-size: 2.5rem; font-weight: 200; letter-spacing: 0.05em; margin: 0.5rem 0; }
        .event-date { color: var(--text-secondary); font-size: 0.9rem; font-weight: 300; }
        .event-description { color: var(--text-secondary); font-weight: 300; margin-top: 1rem; max-width: 700px; line-height: 1.8; }
        .photo-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1rem; }
        .photo-item { position: relative; overflow: hidden; border-radius: 4px; cursor: pointer; aspect-ratio: 3/2; }
        .photo-item img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s; }
        .photo-item:hover img { transform: scale(1.05); }
        .photo-hover { position: absolute; inset: 0; background: rgba(11,11,11,0.5); display: flex; align-items: center; justify-content: center; opacity: 0; transition: opacity 0.3s; }
        .photo-item:hover .photo-hover { opacity: 1; }
        .photo-expand { padding: 0.5rem 1.5rem; border: 1px solid white; color: white; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.1em; }
        .no-photos { text-align: center; padding: 4rem 0; color: var(--text-secondary); }
        .lightbox { position: fixed; inset: 0; background: rgba(0,0,0,0.95); z-index: 1000; display: flex; align-items: center; justify-content: center; }
        .lightbox-header { position: absolute; top: 0; left: 0; right: 0; display: flex; justify-content: space-between; align-items: center; padding: 1rem 2rem; z-index: 10; }
        .lightbox-header span { color: var(--text-secondary); font-size: 0.85rem; }
        .lightbox-header button { background: none; color: var(--text-primary); font-size: 1.5rem; }
        .lightbox-prev, .lightbox-next { position: absolute; top: 50%; transform: translateY(-50%); background: none; color: var(--text-primary); font-size: 2rem; padding: 1rem; z-index: 10; }
        .lightbox-prev { left: 1rem; }
        .lightbox-next { right: 1rem; }
        .lightbox-image-container { max-width: 90vw; max-height: 85vh; }
        .lightbox-image-container img { max-width: 100%; max-height: 85vh; object-fit: contain; }
        .whatsapp-event-btn { position: fixed; bottom: 2rem; right: 2rem; display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.8rem 1.5rem; background: #25D366; color: white; border-radius: 4px; font-size: 0.85rem; z-index: 50; box-shadow: 0 4px 15px rgba(37,211,102,0.3); transition: transform 0.3s; }
        .whatsapp-event-btn:hover { transform: scale(1.05); }
        .not-found { padding: 10rem 2rem; text-align: center; }
        .not-found h2 { font-weight: 200; margin-bottom: 1rem; }
        .not-found a { color: var(--accent); }
        .loading-screen { display: flex; align-items: center; justify-content: center; height: 100vh; }
        .spinner { width: 40px; height: 40px; border: 2px solid var(--border); border-top-color: var(--accent); border-radius: 50%; animation: spin 0.8s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
        @media (max-width: 768px) {
          .photo-grid { grid-template-columns: 1fr 1fr; }
          .event-detail { padding: 6rem 1rem 2rem; }
          .event-detail-header h1 { font-size: 1.8rem; }
        }
        @media (max-width: 480px) {
          .photo-grid { grid-template-columns: 1fr; }
        }
      `}</style>
    </div>
  );
}
