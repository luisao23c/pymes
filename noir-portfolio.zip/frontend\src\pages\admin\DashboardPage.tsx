import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { api } from '../../services/api';
import { FiImage, FiCalendar, FiMessageSquare } from 'react-icons/fi';

export default function DashboardPage() {
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    api.dashboard.stats().then(setStats).catch(() => {});
  }, []);

  const cards = [
    { label: 'Eventos', value: stats?.totalEvents || 0, icon: <FiCalendar />, color: '#C0A060' },
    { label: 'Fotos', value: stats?.totalPhotos || 0, icon: <FiImage />, color: '#3498db' },
    { label: 'Mensajes sin leer', value: stats?.unreadMessages || 0, icon: <FiMessageSquare />, color: '#e74c3c' },
  ];

  return (
    <div className="dashboard">
      <motion.h1
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
      >
        Dashboard
      </motion.h1>
      <p className="dashboard-subtitle">Resumen de tu portafolio</p>

      <div className="stats-grid">
        {cards.map((card, i) => (
          <motion.div
            key={card.label}
            className="stat-card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <div className="stat-icon" style={{ color: card.color }}>{card.icon}</div>
            <div className="stat-value">{card.value}</div>
            <div className="stat-label">{card.label}</div>
          </motion.div>
        ))}
      </div>

      <style>{`
        .dashboard { }
        .dashboard h1 { font-size: 1.8rem; font-weight: 200; letter-spacing: 0.05em; margin-bottom: 0.25rem; }
        .dashboard-subtitle { color: var(--text-secondary); font-weight: 300; font-size: 0.9rem; margin-bottom: 2rem; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; }
        .stat-card { background: var(--bg-secondary); border: 1px solid var(--border); border-radius: 4px; padding: 1.5rem; display: flex; flex-direction: column; gap: 0.5rem; }
        .stat-icon { font-size: 1.5rem; }
        .stat-value { font-size: 2.5rem; font-weight: 200; }
        .stat-label { color: var(--text-secondary); font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.1em; }
      `}</style>
    </div>
  );
}
